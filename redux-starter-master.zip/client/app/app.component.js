import template from './app.html';
import './app.scss';

let appComponent = {
  template,
  restrict: 'E'
};

export default appComponent;
