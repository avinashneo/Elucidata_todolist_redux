import TodoActions from '../../actions/todo.actions';
import { SHOW_ALL, SHOW_COMPLETED, SHOW_ACTIVE } from '../../constants/TodoFilters';
const TODO_FILTERS = {
  [SHOW_ALL]: () => true,
  [SHOW_ACTIVE]: todo => !todo.completed,
  [SHOW_COMPLETED]: todo => todo.completed
}
class HomeController {
  constructor($ngRedux) {

    this.todo = '';
    this.filter = SHOW_ALL;
    this.unsubscribe = $ngRedux.connect(this.mapStateToThis, TodoActions)(this);
  }

  submitTodo(){
    this.addTodo(this.todo);
    this.todo = '';
  }

  $onDestroy(){
    this.unsubscribe();
  }

  mapStateToThis(state,show) {console.log(show);
      return {
            todos: state.todos
      };
  }
  $showFn(todo) {console.log(todo)
		/*if (show === "All") {
			return true;
		}else if(todo.completed && show === "Complete"){
			return true;
		}else if(!todo.completed && show === "Incomplete"){
			return true;
		}else{
			return false;
		*/
	}
}

HomeController.$inject = ["$ngRedux"];

export default HomeController;
