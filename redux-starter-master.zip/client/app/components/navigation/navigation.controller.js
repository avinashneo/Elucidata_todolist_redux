class NavigationController {
  constructor() {

  }
}

export default NavigationController;
