import { TODOS } from '../constants/todos';

function addTodo(todo){
    return {
        type: TODOS.ADD_TODO,
        payload: todo
    }
}

function removeTodo(id){
    return {
        type: TODOS.REMOVE_TODO,
        payload: id
    };
}
function completeTodo(id){
    return {
        type: TODOS.COMPLETE_TODO,
        payload: id
    };
}
export default { addTodo, removeTodo, completeTodo };
