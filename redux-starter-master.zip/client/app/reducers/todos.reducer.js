import { TODOS } from '../constants/todos';

const initialState = [
  {
    text: 'Use Redux',
    completed: false,
    id: 0
  }
]

export function TodosReducer(state = initialState, action) {
    switch(action.type) {
        case TODOS.ADD_TODO:
            console.log(action);
           return [
        {
          id: state.reduce((maxId, todo) => Math.max(todo.id, maxId), -1) + 1,
          completed: false,
          text: action.payload
        },
        ...state
      ]
        case TODOS.REMOVE_TODO:
            return state.filter(todo =>
        todo.id !== action.payload
      )
      case TODOS.COMPLETE_TODO:
      return state.map(todo =>
        todo.id === action.payload ? Object.assign({}, todo, { completed: !todo.completed }) : todo
      )
        default:
            return state;
    }
}
